# 🚀💰fuzz4bounty [![Twitter](https://img.shields.io/badge/0xPugazh-%231DA1F2.svg?logo=Twitter&logoColor=white)](https://twitter.com/0xPugazh) [![LinkedIn](https://img.shields.io/badge/0xPugazh-%230077B5.svg?logo=linkedin&logoColor=white)](https://linkedin.com/in/0xPugazh) 

![carbon](https://user-images.githubusercontent.com/75373225/227513641-317d79d5-82ff-420e-b524-214555426dc2.png)

## 🚀Wordlists for Bug Bounty Hunting

> **This repository contains publicly available wordlists for Bug hunting. The main Objective for creating this repo is to bring all the available worlists at one place.**

> **Wordlists will be updated regularly.**

> **Feel free to contribute, Pull Requests are welcomed.**

## Support Me
<a href="https://www.buymeacoffee.com/0xPugazh" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>

## Other Awesome  Wordlists
+ [OneListForAll](https://github.com/six2dez/OneListForAll)
+ [SecLists](https://github.com/danielmiessler/SecLists)
+ [fuzz.txt](https://github.com/Bo0oM/fuzz.txt)
+ [Dirsearch](https://raw.githubusercontent.com/maurosoria/dirsearch/master/db/dicc.txt)
+ [Bug-Bounty-Wordlists](https://raw.githubusercontent.com/Karanxa/Bug-Bounty-Wordlists/main/fuzz.txt)
+ [Trickest](https://github.com/trickest/wordlists)
+ [GodfatherOrwa-Wordlist](https://github.com/orwagodfather/WordList)

